package com.xtrapp.the_gorgeous_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
